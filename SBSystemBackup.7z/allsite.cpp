//用户所有景点列表
#include "allsite.h"
#include "ui_allsite.h"
#include "global.h"



allsite::allsite(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::allsite)
{
    ui->setupUi(this);
}

allsite::~allsite()
{
    delete ui;
}

//勾选有票
void allsite::on_ticket_stateChanged(int arg1)
{
    if(ui->ticket->isChecked()==true) {
        qDebug()<<"ticket"<<" "<<"down";
    }
    else qDebug()<<"up";
}

//勾选折扣
void allsite::on_discount_stateChanged(int arg1)
{
    qDebug()<<"discount";
    if(ui->discount->isChecked()==true) {
        qDebug()<<"ticket"<<" "<<"down";
    }
    else qDebug()<<"up";
}

//点击返回
void allsite::on_back_clicked()
{
    qDebug()<<"back";
    emit hide_now();
    //back = 1;
}

//每个景点
void allsite:: create_item(site sites)
{
    show_site *container=new show_site(this);
    container->send_info(sites,QDateTime::currentDateTime());//记着改
    QListWidgetItem *item = new QListWidgetItem();
    QSize size = item->sizeHint();
    item->setSizeHint(container->size());
    ui->site_list->addItem(item);
    ui->site_list->setItemWidget(item,container);
}

void allsite::show_info()
{
    QList<site>buf=man->get_every_site();
    for(int i=0;i<buf.size();i++)
    {
        qDebug()<<"site :"<<buf.at(i).name;
        if(buf.at(i).is_pub==1)
        {
            create_item(buf.at(i));
        }
    }
}



void allsite::on_commandLinkButton_clicked()
{

}
