#include "global.h"
SBSmanager *man;
site empty_site;
order empty_order;
